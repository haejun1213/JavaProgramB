package kr.ac.kopo.user;

public class HJUserService implements UserService{
    private UserDAO userDAO;

    public HJUserService(UserDAO userDAO) {
        this.userDAO = userDAO;
    }

    // 로그인 서비스 메서드
    public UserVO login(UserVO user) {
        try {
            return userDAO.login(user.getUserId(), user.getPassword());
        } catch (Exception e) {
            System.out.println("로그인 실패: " + e.getMessage());
            return null;
        }
    }
}
