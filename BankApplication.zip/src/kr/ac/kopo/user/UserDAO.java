package kr.ac.kopo.user;

import java.sql.SQLException;

public interface UserDAO {
    UserVO login(String userId, String password) throws SQLException; // 로그인 메서드
}
