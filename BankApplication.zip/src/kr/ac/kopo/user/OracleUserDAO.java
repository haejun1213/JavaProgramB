package kr.ac.kopo.user;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import kr.ac.kopo.common.DBConnectionFactory;

public class OracleUserDAO implements UserDAO {

	@Override
	public UserVO login(String userId, String password) throws SQLException {
		UserVO user = null;

		String sql = "SELECT USER_ID, USER_PASSWORD, USER_NAME, USER_EMAIL, USER_REGDATE "
				   + "  FROM users WHERE USER_ID = ? AND USER_PASSWORD = ?";
		try (Connection conn = DBConnectionFactory.getConnection();
				PreparedStatement pstmt = conn.prepareStatement(sql)) {
			pstmt.setString(1, userId);
			pstmt.setString(2, password);

			ResultSet rs = pstmt.executeQuery();
			if (rs.next()) {
				user = new UserVO(rs.getString("USER_ID"), rs.getString("USER_PASSWORD"), rs.getString("USER_NAME"),
						rs.getString("USER_EMAIL"), rs.getDate("USER_REGDATE"));
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		return user;
	}
}
