package kr.ac.kopo.user;

public interface UserService {
	UserVO login(UserVO user);
}
