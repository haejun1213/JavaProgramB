package kr.ac.kopo.user;

import java.util.Date;

public class UserVO {
    private String userId;       // 사용자 ID
    private String password;     // 사용자 비밀번호
    private String name;         // 사용자 이름
    private String email;        // 사용자 이메일
    private Date regdate;        // 사용자 등록일

    // 기본 생성자
    public UserVO() {}

    // 모든 필드를 포함한 생성자
    public UserVO(String userId, String password, String name, String email, Date regdate) {
        this.userId = userId;
        this.password = password;
        this.name = name;
        this.email = email;
        this.regdate = regdate;
    }

    // Getter와 Setter 메서드
    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public Date getRegdate() {
        return regdate;
    }

    public void setRegdate(Date regdate) {
        this.regdate = regdate;
    }

    // toString() 메서드
    @Override
    public String toString() {
        return "UserVO [userId=" + userId + ", password=" + password + ", name=" + name 
               + ", email=" + email + ", regdate=" + regdate + "]";
    }
}
