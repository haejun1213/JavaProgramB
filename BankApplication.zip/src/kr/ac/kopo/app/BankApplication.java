package kr.ac.kopo.app;

import java.util.List;
import java.util.Scanner;

import kr.ac.kopo.account.AccountDAO;
import kr.ac.kopo.account.AccountHistoryDAO;
import kr.ac.kopo.account.AccountHistoryVO;
import kr.ac.kopo.account.AccountService;
import kr.ac.kopo.account.AccountVO;
import kr.ac.kopo.account.HJAccountService;
import kr.ac.kopo.account.OracleAccountDAO;
import kr.ac.kopo.account.OracleAccountHistoryDAO;
import kr.ac.kopo.user.HJUserService;
import kr.ac.kopo.user.OracleUserDAO;
import kr.ac.kopo.user.UserDAO;
import kr.ac.kopo.user.UserService;
import kr.ac.kopo.user.UserVO;

public class BankApplication {
    
    private static Scanner sc = new Scanner(System.in);
    private static AccountService as;
    private static UserService us;
    private static UserVO loginedUser;
    
    public static void main(String[] args) {
        
        // DB 결정
        AccountDAO accountDAO = new OracleAccountDAO();
        AccountHistoryDAO accountHistoryDAO = new OracleAccountHistoryDAO();
        UserDAO userDAO = new OracleUserDAO();
        
        // DB에 대한 의존성 주입
        as = new HJAccountService(accountDAO, accountHistoryDAO );
        us = new HJUserService(userDAO);
        
        // 로그인
        UserVO user = new UserVO();
        user.setUserId("haejun2");
        user.setPassword("1234");
        
        loginedUser = us.login(user);
        
        System.out.println("+----------------------------------------------------------------------+");
        System.out.printf(" %s(%s)님, Final Bank에 오신 것을 환영합니다.\n", loginedUser.getName(), loginedUser.getUserId());
        
        int menu = 0;
        
        do {
            
            System.out.println("------------------------------------------------------------------------");
            System.out.println("1. 계좌목록 | 2. 입금 | 3. 출금 | 4. 입출금내역 | 5. 계좌개설 | 6. 계좌해지 | 0. 종료");
            System.out.println("------------------------------------------------------------------------");
            System.out.print(">> 선택 : ");
            
            menu = getValidatedInteger(sc);
            
            switch (menu) {
                case 1 : // 계좌목록
                    viewAccountList();
                    break;
                case 2 : // 입금
                    deposit();
                    break;
                case 3 : // 출금
                    withdraw();
                    break;
                case 4 : // 입출금내역
                    historyAccount();
                    break;
                case 5 : // 계좌개설 
                    createAccount();
                    break;
                case 6 : // 계좌해지
                    removeAccount();
                    break;
                case 0 : // 종료                
                    exit();
                    break;
                default :
                    System.out.println("메뉴에 있는 번호를 입력하세요.");
            }
        
        } while (menu != 0);
    }

    private static void historyAccount() {
        System.out.print("계좌번호 : ");
        int accountNo = Integer.parseInt(sc.nextLine());
        
        // 입출금 내역을 가져오는 로직을 구현
        List<AccountHistoryVO> historyList = as.getAccountHistory(accountNo);
        
        if (historyList != null && !historyList.isEmpty()) {
            System.out.println("입출금 내역:");
            for (AccountHistoryVO history : historyList) {
                System.out.println(history.toString());
            }
        } else {
            System.out.println("입출금 내역이 없습니다.");
        }
    }

    private static void createAccount() {
        String userId = loginedUser.getUserId();
        
        System.out.print("초기 입금액 : ");
        int money = Integer.parseInt(sc.nextLine());
        
        // 계좌 개설
        if (as.createAccount(userId, money)) {
            System.out.println(userId + "님의 계좌가 등록되었습니다.");
        }
    }

    private static void viewAccountList() {
        List<AccountVO> accountList = as.listAllAccount();
        if (accountList != null) { 
            for (AccountVO account : accountList) {
                System.out.println(account.toString());
            }
        } else {
            System.out.println("등록된 계좌가 없습니다.");
        }
    }

    private static void deposit() {
        // 계좌번호, 금액
        System.out.print("계좌번호 : ");
        int accountNo = Integer.parseInt(sc.nextLine());
        
        System.out.print("예금액 : ");
        int money = Integer.parseInt(sc.nextLine());
        
        // 입금
        if (as.deposit(accountNo, money)) {
            System.out.println("계좌번호 " + accountNo + "에 " + money + "원이 입금되었습니다.");
        }
    }

    private static void withdraw() {
        // 계좌번호, 금액
        System.out.print("계좌번호 : ");
        int accountNo = Integer.parseInt(sc.nextLine());
        
        System.out.print("출금액 : ");
        int money = Integer.parseInt(sc.nextLine());
        
        // 출금
        if (as.withdraw(accountNo, money)) {
            System.out.println("계좌번호 " + accountNo + "에서 " + money + "원이 출금되었습니다.");
            
        }
    }

    private static void removeAccount() {
        System.out.print("계좌번호 : ");
        int accountNo = Integer.parseInt(sc.nextLine());
        
        // 계좌 해지
        if (as.removeAccount(accountNo)) {
            System.out.println("계좌번호 " + accountNo + "인 계좌를 해지하였습니다.");
        }
    }

    private static void exit() {
        System.out.println("HJ 은행 서비스를 종료합니다.");
    }
    
    public static int getValidatedInteger(Scanner sc) {
        try {
            return Integer.parseInt(sc.nextLine());
        } catch (NumberFormatException e) {
            System.out.println("유효하지 않은 입력입니다. 숫자만 입력해주세요.");
            System.out.print(">> 선택 : ");
            return getValidatedInteger(sc);
        }
    }
}
