package kr.ac.kopo.account;

import java.util.Date;

public class AccountHistoryVO {
    private int historyNo;   // 내역 번호
    private int accountNo;   // 계좌 번호
    private String userId;   // 사용자 ID
    private String actionType; // 거래 종류 (입금, 출금, 계좌 개설 등)
    private int amount;      // 거래 금액
    private int balanceAfter; // 거래 후 잔액
    private Date actionDate;  // 거래 날짜
    
    // 생성자
    public AccountHistoryVO(int historyNo, int accountNo, String userId, String actionType, int amount, int balanceAfter, Date actionDate) {
        this.historyNo = historyNo;
        this.accountNo = accountNo;
        this.userId = userId;
        this.actionType = actionType;
        this.amount = amount;
        this.balanceAfter = balanceAfter;
        this.actionDate = actionDate;
    }

    // getter, setter
    public int getHistoryNo() {
        return historyNo;
    }

    public void setHistoryNo(int historyNo) {
        this.historyNo = historyNo;
    }

    public int getAccountNo() {
        return accountNo;
    }

    public void setAccountNo(int accountNo) {
        this.accountNo = accountNo;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getActionType() {
        return actionType;
    }

    public void setActionType(String actionType) {
        this.actionType = actionType;
    }

    public int getAmount() {
        return amount;
    }

    public void setAmount(int amount) {
        this.amount = amount;
    }

    public int getBalanceAfter() {
        return balanceAfter;
    }

    public void setBalanceAfter(int balanceAfter) {
        this.balanceAfter = balanceAfter;
    }

    public Date getActionDate() {
        return actionDate;
    }

    public void setActionDate(Date actionDate) {
        this.actionDate = actionDate;
    }

    @Override
    public String toString() {
        return "AccountHistoryVO [historyNo=" + historyNo + ", accountNo=" + accountNo + ", userId=" + userId
                + ", actionType=" + actionType + ", amount=" + amount + ", balanceAfter=" + balanceAfter
                + ", actionDate=" + actionDate + "]";
    }
}
