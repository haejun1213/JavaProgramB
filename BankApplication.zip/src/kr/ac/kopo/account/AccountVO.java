package kr.ac.kopo.account;

import java.util.Date;

public class AccountVO {
	private int no;
	private String userId;
	private int balance;
	private Date regdate;
	
	public AccountVO(int no, String userId, int balance, Date regdate) {
		this.no = no;
		this.userId = userId;
		this.balance = balance;
		this.regdate = regdate;
	}
		
	public int getNo() {
		return no;
	}
	public void setNo(int no) {
		this.no = no;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public int getBalance() {
		return balance;
	}
	public void setBalance(int balance) {
		this.balance = balance;
	}
	public Date getRegdate() {
		return regdate;
	}
	public void setRegdate(Date regdate) {
		this.regdate = regdate;
	}

	@Override
	public String toString() {
		return "AccountVO [no=" + no + ", userId=" + userId + ", balance=" + balance + ", regdate=" + regdate + "]";
	}

	public Object getAccountNo() {
		// TODO Auto-generated method stub
		return null;
	}
	
}