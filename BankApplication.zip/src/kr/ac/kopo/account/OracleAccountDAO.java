package kr.ac.kopo.account;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import kr.ac.kopo.common.DBConnectionFactory;

public class OracleAccountDAO implements AccountDAO {

	@Override
	public int insert(String userId, int money) {

		int result = 0;

		// sql문
		String sql = new StringBuilder().append("insert into account(ACCOUNT_NO, user_id, balance, regdate)")
				.append("values (bank_account_seq.nextval, ? , ? , sysdate)").toString();

		try (
				// db 연결
				Connection conn = DBConnectionFactory.getConnection();
				// 실행 객체 만들고
				PreparedStatement pstmt = conn.prepareStatement(sql);) {

			// sql문 파라미터 값 setting
			pstmt.setString(1, userId);
			pstmt.setInt(2, money);

			// 실행 요청
			result = pstmt.executeUpdate();

		} catch (Exception e) {
			System.out.println(e.toString());
		}

		return result;
	}

	@Override
	public AccountVO select(int accountNo) {

		AccountVO account = null;

		String sql = "select * " + "  from account " + " where ACCOUNT_NO = ?";
		try (Connection conn = DBConnectionFactory.getConnection();
				PreparedStatement pstmt = conn.prepareStatement(sql);) {
			pstmt.setInt(1, accountNo);

			try (ResultSet rs = pstmt.executeQuery()) {
				if (rs.next()) {
					String userId = rs.getString("user_id");
					int balance = rs.getInt("balance");
					Date regdate = rs.getDate("regdate");
					account = new AccountVO(accountNo, userId, balance, regdate);
				}
			}

		} catch (Exception e) {
			System.out.println(e.toString());
		}

		return account;
	}

	@Override
	public List<AccountVO> selectAll() {
		List<AccountVO> accountList = new ArrayList<AccountVO>();

		String sql = "select * from account";

		try (Connection conn = DBConnectionFactory.getConnection();
				PreparedStatement pstmt = conn.prepareStatement(sql);
				ResultSet rs = pstmt.executeQuery();) {
			while (rs.next()) {
				int accountNo = rs.getInt("ACCOUNT_NO");
				String userId = rs.getString("user_id");
				int balance = rs.getInt("balance");
				Date regdate = rs.getDate("regdate");
				accountList.add(new AccountVO(accountNo, userId, balance, regdate));
			}

		} catch (Exception e) {
			System.out.println(e.toString());
		}

		return accountList;
	}

	@Override
	public int updateBalance(int no, int balance) {
		int result = 0;

		String sql = new StringBuilder().append("update account ").append("set balance=?").append("where ACCOUNT_NO=?")
				.toString();

		try (Connection conn = DBConnectionFactory.getConnection();
				PreparedStatement pstmt = conn.prepareStatement(sql);) {
			pstmt.setInt(1, balance);
			pstmt.setInt(2, no);

			// 실행
			result = pstmt.executeUpdate();

		} catch (Exception e) {
			System.out.println(e.toString());
		}

		return result;
	}

	@Override
	public int delete(int no) {
		int result = 0;

		String sql = new StringBuilder().append("delete account").append(" where ACCOUNT_NO=?").toString();

		try (Connection conn = DBConnectionFactory.getConnection();
				PreparedStatement pstmt = conn.prepareStatement(sql);) {
			pstmt.setInt(1, no);

			result = pstmt.executeUpdate();

		} catch (Exception e) {
			e.printStackTrace();
		}

		return result;
	}

	@Override
	public AccountVO selectOrderNoFrist(String userId) {

		String sql = new StringBuilder().append("SELECT * ").append("FROM ( ").append("    SELECT * ")
				.append("    FROM account ").append("    WHERE USER_ID = ? ").append("    ORDER BY ACCOUNT_NO DESC) ")
				.append("WHERE ROWNUM = 1").toString();

		try (Connection conn = DBConnectionFactory.getConnection();
				PreparedStatement pstmt = conn.prepareStatement(sql);) {
			pstmt.setString(1, userId);

			try (ResultSet rs = pstmt.executeQuery()) {
				if (rs.next()) {
					int accountNo = rs.getInt("ACCOUNT_NO");
					int balance = rs.getInt("balance");
					Date regdate = rs.getDate("regdate");
					return new AccountVO(accountNo, userId, balance, regdate);

				}
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

		return null;
	}

}