package kr.ac.kopo.account;

import java.util.List;

public interface AccountDAO {
	int insert(String userId, int money);
	AccountVO select(int no);
	List<AccountVO> selectAll();
	int updateBalance(int no, int balance);
	int delete(int no);
	AccountVO selectOrderNoFrist(String userId);
}