package kr.ac.kopo.account;

import java.util.List;

public class HJAccountService implements AccountService {

    private AccountDAO accountDAO;
    private AccountHistoryDAO accountHistoryDAO;
    
    public HJAccountService(AccountDAO accountDAO, AccountHistoryDAO accountHistoryDAO) {
        this.accountDAO = accountDAO;
        this.accountHistoryDAO = accountHistoryDAO;
    }

    @Override
    public boolean createAccount(String userId, int money) {
        int result = accountDAO.insert(userId, money);
        if (result == 1) {
            AccountVO account = accountDAO.selectOrderNoFrist(userId);
            accountHistoryDAO.addAccountHistory(account.getNo(), userId, "개설", 0, account.getBalance());
            return true;
        }
        return false;
    }

    @Override
    public List<AccountVO> listAllAccount() {
        return accountDAO.selectAll();
    }

    @Override
    public boolean deposit(int no, int money) {
        AccountVO account = accountDAO.select(no);
        if (account != null) {
            int balance = account.getBalance() + money;
            accountDAO.updateBalance(no, balance);
            accountHistoryDAO.addAccountHistory(no, account.getUserId(), "입금", money, balance);
            return true;
        }
        return false;
    }

    @Override
    public boolean withdraw(int no, int money) {
        AccountVO account = accountDAO.select(no);
        if (account != null) {
            int balance = account.getBalance() - money;
            if (balance >= 0) {
                accountDAO.updateBalance(no, balance);
                accountHistoryDAO.addAccountHistory(no, account.getUserId(), "출금", money, balance);
                return true;
            }
        }
        return false;
    }

    @Override
    public boolean removeAccount(int no) {
        int result = accountDAO.delete(no);
        if (result == 1) {
            AccountVO account = accountDAO.select(no);
            accountHistoryDAO.addAccountHistory(no, account.getUserId(), "해지", 0, 0);
            return true;
        }
        return false;
    }

    @Override
    public List<AccountHistoryVO> getAccountHistory(int accountNo) {
        return accountHistoryDAO.getAccountHistory(accountNo);
    }

    @Override
    public AccountVO getAccountByUserId(String userId) {
        return accountDAO.selectOrderNoFrist(userId);
    }

    @Override
    public void addAccountHistory(Object accountNo, String userId, String actionType, int amount, int balanceAfter) {
        if (accountNo instanceof Integer) {
            accountHistoryDAO.addAccountHistory((Integer) accountNo, userId, actionType, amount, balanceAfter);
        }
    }

    @Override
    public AccountVO getAccountByAccountNo(int accountNo) {
        return accountDAO.select(accountNo);
    }
}
