package kr.ac.kopo.account;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import kr.ac.kopo.common.DBConnectionFactory;

public class OracleAccountHistoryDAO implements AccountHistoryDAO {

    @Override
    public List<AccountHistoryVO> getAccountHistory(int accountNo) {
        List<AccountHistoryVO> historyList = new ArrayList<>();
        
        String sql = "SELECT * FROM account_history WHERE ACCOUNT_NO = ? ORDER BY ACTION_DATE DESC";
        
        try (Connection conn = DBConnectionFactory.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, accountNo);
            
            try (ResultSet rs = pstmt.executeQuery()) {
                while (rs.next()) {
                    int historyNo = rs.getInt("HISTORY_NO");
                    String userId = rs.getString("USER_ID");
                    String actionType = rs.getString("ACTION_TYPE");
                    int amount = rs.getInt("AMOUNT");
                    int balanceAfter = rs.getInt("BALANCE_AFTER");
                    Date actionDate = rs.getDate("ACTION_DATE");
                    
                    AccountHistoryVO history = new AccountHistoryVO(
                            historyNo, accountNo, userId, actionType, amount, balanceAfter, actionDate
                    );
                    historyList.add(history);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        
        return historyList;
    }

    @Override
    public void addAccountHistory(int accountNo, String userId, String actionType, int amount, int balanceAfter) {
        String sql = "INSERT INTO account_history (HISTORY_NO, ACCOUNT_NO, USER_ID, ACTION_TYPE, AMOUNT, BALANCE_AFTER, ACTION_DATE) "
                   + "VALUES (seq_history_no.NEXTVAL, ?, ?, ?, ?, ?, SYSDATE)";
        
        try (Connection conn = DBConnectionFactory.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, accountNo);
            pstmt.setString(2, userId);
            pstmt.setString(3, actionType);
            pstmt.setInt(4, amount);
            pstmt.setInt(5, balanceAfter);
            
            pstmt.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
