package kr.ac.kopo.account;

import java.util.List;

public interface AccountHistoryDAO {
    // 입출금 내역 조회
    List<AccountHistoryVO> getAccountHistory(int accountNo);
    
    // 입출금 내역 추가
    void addAccountHistory(int accountNo, String userId, String actionType, int amount, int balanceAfter);
}
