package kr.ac.kopo.account;

public class InsufficientBalanceException extends Exception {

	public InsufficientBalanceException() {
	}

	public InsufficientBalanceException(String message) {
		super(message);
	}

}
