package kr.ac.kopo.account;

import java.util.List;

public interface AccountService {
	boolean createAccount(String owner, int money);
	List<AccountVO> listAllAccount();
	boolean deposit(int no, int money);
	boolean withdraw(int no, int money);
	boolean removeAccount(int no);
	List<AccountHistoryVO> getAccountHistory(int accountNo);
	AccountVO getAccountByUserId(String userId);
	void addAccountHistory(Object accountNo, String userId, String string, int i, int balance);
	AccountVO getAccountByAccountNo(int accountNo);
}